import speech_recognition as sr           
import os
import webbrowser
import openai
import datetime
import random




import google.generativeai as genai
import os

def ai(prompt):
    
    os.environ["API_KEY"] = "AIzaSyDN9FOsZAG1SxGCvitBWkNX6FH2iQtAqxA"
    text = f"OpenAI response for Prompt: {prompt}\n*****************\n\n"
    genai.configure(api_key=os.environ["API_KEY"])
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt)
    text += response["choices"][0]["text"]
    if not os.path.exists("Openai"):
        os.mkdir("Openai")
    with open(f"Openai/{prompt[:30]}.txt", "w") as f:
        f.write(text)

    prompt=prompt 






def say(text):
    os.system(f"say {text}")
def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        #r.pause_threshold =  1 
        audio = r.listen(source)
        try:
            print("Recognizing...")
            query = r.recognize_google(audio, language="en-in")
            say(f"User said: {query}")
            return query
        except Exception as e:
            return "Some Error Occurred. Sorry from Jarvis"
if __name__ == '__main__' :
    print('PyCharm')
    say("Hello I am MONA ")
    print("Listening.....")
    query = takeCommand()
    sites = [["youtube", "https://www.youtube.com"],["wikipedia","https://www.wikipedia.com"],["google", "https://www.google.com"],]
    for site in sites:
        if f"Open {site[0]}".lower() in query.lower():
            say(f"Opening {site[0]} sir...")
            webbrowser.open(site[1])
        if "open music" in query:
            musicpath = " "
            os.system(f"open {musicpath}")
        if " the time" in query:
            musicpath = " "
            hour = datetime.datetime.now().strftime("%H")
            min = datetime.datetime.now().strftime("%M")
            say(f" Sir time is {hour} and {min} minutes") 
        if "open message app ".lower() in query.lower():
            os.system(f"open /System/Applications/Messages.app") 
            #apps
        if "using artificial intelligence".lower() in query.lower():
            ai(prompt=query)
              
